from ..examples.settings import *
